/**
 * @class Something
 * 
 * ## boom
 * 
 * [Bar]
 * 
 * goes
 * blah
 * @constructor foo bar
 * man
 * @tag home
 */
Something = function() {

}
/**
 * @prototype
 */
Something.prototype = {
	/**
	 * this documents the following method
	 * @param {Number} foo something something
	 * @codestart
	 * foo = {}
	 * @codeend
	 */
	myMethod: function( foo ) {

	},
	/**
	 * @attribute
	 * this is my comment
	 */
	foo: 2
}

/**
 * @static
 */
Something.
/**
 * holler
 */
staticSomething = function() {

}


/**
 * @class
 * this is a comment
 * @tag home
 */
Bar = function() {

}

/**
 * @add Something.static
 */
Something.
/**
 * holler
 */
foobar = function() {

}


/**
 * @page overview My Overview
 * <h1>Hello</h1>
 * @tag home
 */
//comment?